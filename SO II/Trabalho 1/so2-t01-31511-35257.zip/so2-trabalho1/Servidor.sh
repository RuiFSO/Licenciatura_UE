#!/bin/bash

java -cp dist/so2-trabalho1.jar so2.trabalho1.QuestServidor 9000 alunos.di.uevora.pt l31511 l31511 Rui31511
