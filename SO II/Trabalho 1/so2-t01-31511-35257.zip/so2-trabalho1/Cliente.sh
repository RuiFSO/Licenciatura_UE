#!/bin/bash

java -cp dist/so2-trabalho1.jar so2.trabalho1.QuestCliente localhost 9000
