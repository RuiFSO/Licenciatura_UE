

void check_declist(declist *d);
type *check_decl(decl *d);

type *check_exps(exps *e);

void check_stmlist(stmlist *slist);
type *check_stm(stm *s);

void check_arglist(arglist *alist);
type *check_arg(arg *a);
